# VidFetch — GitHub-e Upload Kora: A–Z Guide (Banglish)

Repo: **https://github.com/naimxislambd/vidfetch-extension**

Current version: **v1.4.4** — helper auto-start (native messaging), yt-dlp auto-update, fixed extension ID.

## A. GitHub mane ki?
GitHub holo code rakhar jayga. Ekhane VidFetch-er sob file thakbe — extension, helper, setup file, README. Jekono PC theke download kora jabe, ar notun version ashle purano file bodle deya jabe.

## B. Ami (Muse) ja korlam
1. Tomar pathano `VidFetch-1.4.2.zip` khule check korlam — version 1.4.2, thumbnail sudhu Thumbnail button-e.
2. Helper-er version thik korlam (zip-e 1.4.0 lekha chilo, 1.4.2 kore dilam).
3. GitHub-e notun **public** repo banano holo: `vidfetch-extension`.
4. Sob text file push kora holo (README, extension, helper, setup file).
5. 4 ta icon PNG file alada kore web-e upload korte hoy — karon push tool sudhu text file ney. Icon upload na korle Chrome extension load hote warning dite pare.

## C. Nijer hate GitHub-e upload korar niom (web, kono software lagbe na)
1. https://github.com/new kholo, sign in koro.
2. Repository name dao: `vidfetch-extension`
3. Description dao: `One VidFetch icon beside the Like button on YouTube - Audio, Video or Thumbnail download.`
4. **Public** tick dao, **Add a README file** tick dao, **Create repository** chapoo.
5. Repo khule **Add file → Upload files** chapoo.
6. Tomar PC-r `vidfetch-extension` folder-er sob file drag kore dao, **Commit changes** chapoo.
7. Zip file upload korte chaile: **Releases → Create a new release** → tag dao `v1.4.2` → zip attach koro → **Publish release**.

## D. Git diye upload korar niom (PC-te Git thakle)
1. Folder-e giye cmd kholo.
2. `git init`
3. `git add .`
4. `git commit -m "VidFetch 1.4.2"`
5. `git branch -M main`
6. `git remote add origin https://github.com/naimxislambd/vidfetch-extension.git`
7. `git push -u origin main`

## E. GitHub theke install korar niom (jake dibe, se evabe korbe)
1. Repo link kholo: https://github.com/naimxislambd/vidfetch-extension
2. Sobuj **Code** button → **Download ZIP**.
3. Zip extract koro.
4. Chrome-e `chrome://extensions` kholo → **Developer mode** ON koro → **Load unpacked** → `extension` folder select koro.
5. `setup.bat` ekbar chalao (Python + ffmpeg + yt-dlp install hobe, helper Windows login-e auto-start hobe).
6. Ar `start-helper.bat` khola rakhar dorkar nai — icon click korlei helper nije start hobe. Kalo window dekhte chaile `start-helper-console.bat` chalao, bondho korte `stop-helper.bat`.
7. YouTube video kholo — Like button-er pashe nil VidFetch icon dekhabe. Click korle Audio / Video / Thumbnail menu khulbe.

## F. Notun version update korar niom
1. Version number barao: `extension/manifest.json` ar `helper.py`-te `VERSION`.
2. README-te "New in" line likho.
3. Zip baniye **Releases**-e `v1.4.3` (porer number) diye publish koro.
4. Purano file bodlate chaile repo-te file khule **pencil icon (Edit)** chapoo, bodle **Commit changes** chapoo.

## G. File list — konta ki kaj kore
| File | Kaj |
|---|---|
| `extension/manifest.json` | Extension-er naam, version, permission |
| `extension/content.js` | Like button-er pashe icon bosano + menu |
| `extension/popup.js` / `popup.html` | Toolbar icon-er popup |
| `extension/background.js` | Download request helper-e pathano |
| `extension/style.css` | Icon + menu-er design |
| `extension/icons/*.png` | Extension-er icon (16/32/48/128) |
| `helper.py` | PC-te download kore (yt-dlp + ffmpeg), port 8766 |
| `setup.bat` / `setup.ps1` | Python + ffmpeg + yt-dlp install |
| `start-helper.bat` | Helper chalano |
| `uninstall.bat` | Helper uninstall |
| `README.md` | Install + use korar niom |
| `LICENSE` | MIT licence — Gugu Grab (Mustavi Rafid) credit |

## H. Mone rakhar kotha
- Helper na cholle download hobe na — icon dekhabe, kintu "helper not running" bolbe.
- Audio/Video download-e thumbnail ashbe na — Thumbnail chaile alada **Thumbnail** button chapte hobe.
- Full playlist tick thakle puro playlist download hobe — ekta video chaile tick dio na.
